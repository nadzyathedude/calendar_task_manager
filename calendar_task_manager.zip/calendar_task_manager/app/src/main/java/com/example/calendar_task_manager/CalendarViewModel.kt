package com.example.calendar_task_manager

import androidx.lifecycle.ViewModel

class CalendarViewModel: ViewModel() {
}