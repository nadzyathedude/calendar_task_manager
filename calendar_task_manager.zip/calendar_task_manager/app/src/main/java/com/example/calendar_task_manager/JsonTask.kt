package com.example.calendar_task_manager

import org.json.JSONObject

class JsonTask {
    val jsonTask = JSONObject()
    fun add() {
        jsonTask.put("name", "task")
        jsonTask.put("id", 1)
        jsonTask.put("description", "My task description")
        jsonTask.put("date_start", 147600000)
        jsonTask.put("date_finish", 147610000)
    }
}